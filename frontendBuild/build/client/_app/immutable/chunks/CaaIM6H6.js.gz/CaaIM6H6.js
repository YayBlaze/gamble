const t="https://yayblaze.com/",o="https://yayblaze.com/api";function c(a){window.location.href=t+a}export{o as b,c as m,t as u};
