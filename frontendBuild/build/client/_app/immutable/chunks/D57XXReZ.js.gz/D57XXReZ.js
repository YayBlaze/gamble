const i="",r="http://71.238.74.210:5300";function t(n){window.location.href=""+n}export{r as b,t as m,i as u};
