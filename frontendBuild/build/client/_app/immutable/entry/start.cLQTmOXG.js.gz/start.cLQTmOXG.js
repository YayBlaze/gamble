import{l as o,a as r}from"../chunks/DbMi15fj.js";export{o as load_css,r as start};
