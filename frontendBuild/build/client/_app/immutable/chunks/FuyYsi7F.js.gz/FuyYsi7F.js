const n="";function o(i){window.location.href=n+i}export{o as m,n as u};
