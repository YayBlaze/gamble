import{a1 as a}from"./DaofkxM2.js";a();
