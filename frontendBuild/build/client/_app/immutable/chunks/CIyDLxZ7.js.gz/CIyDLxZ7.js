const i="",r="http://10.0.0.40:5300";function t(n){window.location.href=""+n}export{r as b,t as m,i as u};
