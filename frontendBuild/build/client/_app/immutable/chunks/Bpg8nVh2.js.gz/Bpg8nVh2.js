const n="https://yayblaze.com/",o="http://71.238.74.210:5300";function a(t){window.location.href=n+t}export{o as b,a as m,n as u};
