import{l as o,a as r}from"../chunks/Av5tIB8k.js";export{o as load_css,r as start};
