const n="https://cs.catlin.edu/pages/2025/blaze/casino";function t(i){window.location.href=n+i}export{t as m,n as u};
