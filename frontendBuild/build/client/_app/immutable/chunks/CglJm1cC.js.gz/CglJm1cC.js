const n="https://cs.catlin.edu/pages/2025/blaze/casino",a="http://10.0.0.40:5300";function c(t){window.location.href=n+t}export{a as b,c as m,n as u};
